import React from 'react';
import {SafeAreaView, View, Text} from 'react-native';

const App = () => {
  return (
    <SafeAreaView>
      <View>
        <Text>Hello React!</Text>
      </View>
    </SafeAreaView>
  );
};

export default App;
