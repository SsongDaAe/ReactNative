import {requireNativeComponent} from 'react-native';

const Counter = requireNativeComponent('Counter');

export default Counter;
