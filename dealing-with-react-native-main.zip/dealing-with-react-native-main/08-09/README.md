Link: https://github.com/velopert/PublicGallery
