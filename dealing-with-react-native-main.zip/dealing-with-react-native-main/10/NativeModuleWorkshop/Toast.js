import {NativeModules} from 'react-native';

const {ToastModule} = NativeModules;

export default ToastModule;
