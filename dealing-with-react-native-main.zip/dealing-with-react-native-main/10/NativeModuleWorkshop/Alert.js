import {NativeModules} from 'react-native';

const {AlertModule} = NativeModules;

export default AlertModule;
