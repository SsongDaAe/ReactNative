//  RCTAlertModule.h
#import <UIKit/UIKit.h>
#import <React/RCTBridgeModule.h>


@interface RCTAlertModule : NSObject <RCTBridgeModule>
@end

