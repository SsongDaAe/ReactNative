Link: https://github.com/velopert/DayLog
